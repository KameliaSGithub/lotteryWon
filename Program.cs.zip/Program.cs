﻿using System;
using System.Collections.Generic;

namespace LotterySimulation
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalTickets = 10000000;
            Random rand = new Random();

            HashSet<string> ticketSet = new HashSet<string>();
            while (ticketSet.Count < totalTickets)
            {
                string barcode = GenerateUniqueBarcode(rand);
                string code = GenerateUniqueCode(rand);
                if (IsThirdDigitOne(barcode) && IsThirdDigitOne(code))
                {
                    ticketSet.Add($"{barcode},{code}");
                }
            }

            List<string> tickets = new List<string>(ticketSet);

            // Shuffle tickets
            ShuffleList(tickets, rand);

            // Find the ticket with the highest prize
            string highestPrizeTicket = null;
            int highestPrize = int.MinValue;
            foreach (var ticket in tickets)
            {
                string[] parts = ticket.Split(',');
                string barcode = parts[0];
                string code = parts[1];
                int prize = CalculatePrize(rand);
                if (prize > highestPrize)
                {
                    highestPrize = prize;
                    highestPrizeTicket = ticket;
                }
            }

            // Output the barcode and code of the ticket with the highest prize to the console
            if (highestPrizeTicket != null)
            {
                Console.WriteLine($"Barcode: {highestPrizeTicket.Split(',')[0]}, Code: {highestPrizeTicket.Split(',')[1]}");
            }
            else
            {
                Console.WriteLine("No winning ticket found.");
            }

            Console.ReadLine(); // Keep the console window open
        }

        // Method to generate a unique 12-digit barcode with every third digit set to '1'
        static string GenerateUniqueBarcode(Random rand)
        {
            string barcode = "";
            for (int i = 0; i < 12; i++)
            {
                if (i % 3 == 2)
                {
                    barcode += "1";
                }
                else
                {
                    barcode += rand.Next(10).ToString();
                }
            }
            return barcode;
        }

        // Method to generate a unique 12-digit code with every third digit set to '1'
        static string GenerateUniqueCode(Random rand)
        {
            string code = "";
            for (int i = 0; i < 12; i++)
            {
                if (i % 3 == 2)
                {
                    code += "1";
                }
                else
                {
                    code += rand.Next(10).ToString();
                }
            }
            return code;
        }

        // Method to check if the third digit of a 12-digit string is '1'
        static bool IsThirdDigitOne(string number)
        {
            return number[2] == '1';
        }

        // Method to shuffle the list of tickets
        static void ShuffleList<T>(List<T> list, Random rand)
        {
            for (int i = list.Count - 1; i > 0; i--)
            {
                int j = rand.Next(0, i + 1);
                T temp = list[i];
                list[i] = list[j];
                list[j] = temp;
            }
        }

        // Method to calculate prize for a winning ticket
        static int CalculatePrize(Random rand)
        {
            // Implement your logic to calculate prize here
            // For demonstration purposes, a random prize between 1 and 1000000 is generated
            return rand.Next(1, 1000001);
        }
    }
}